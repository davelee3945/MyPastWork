#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;
class Help
{
    public:
    void displayMessage()
    {
        cout << "\n                                   9 to go back\n                          1 for option 1\n                              2 for option 2\n";
    }
};

int main ()
{
  int start;
  start:
  cout << "\n                               ===========================================================";
  cout << "\n                                                  BRIDGES AND DRAGONS";  
  cout << "\n                               ===========================================================\n";
    
  
  cout << "\n                                1. New Game \n                                2. Instructions \n                                3. Credits\n ";
  cout << "\n                                ";
  cin >> start;
   if (start == 1)
    {
          string name;
          cout << "\n                               Please enter your charcter name: ";
        
          cin >> name; //getline (cin, name);
          cout << "\n                               Hey " << name << "! Welcome to this C++ text based game\n";

              int house;
              cout << "\n                               You are in your house, what would you like to do?(1= leave, 2= go to bed):  ";

              cin >> house;
              cout <<"\n                               ---------------------------------CHAPTER ONE---------------------------------\n";
                  if (house == 1)
                  {
                      cout << "\n                               You exit through a heavy wooden door and find yourself in the town centre \n";
                        cout << "\n                               Stranger: Hi there! My name is Tina and im here to guide you on your quest!\n";
                        cout << "\n                               "<< name <<": Quest? What Quest!?\n";
                        cout << "\n                               Tina: Don't worry about that, just follow me!\n";
                      cout << "                               -------------------------- PRESS 0 TO CONTINUE -------------------------\n";



                  }
                  else if (house == 2)
                  {
                      cout << "\n                               You work your way up a steep, creaky staircase and throw yourself onto the bed \n";
                  }
                  else
                  {
                      cout << "\n                               You have entered an invalid character\n" ;

                  }
    }
   else if (start == 2)
    {
        cout << "\n\n                              Use the keys as instructed to navigate through the game (often 1,2,3, as shown in menu)\n\n";
       
       goto start;
    }
  
   else
    {
        cout << "\n                                 Made by: Maya Patel, Dave Lee, Dom\n";
       goto start;
       
    }
  
return 0;
}
