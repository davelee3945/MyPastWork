// This file defines the class functions 

#include "domsClass.h" //Load the header file
#include <iostream>
#include <string>

using namespace std;



int RoomClass :: numCounter = 0;

void RoomClass :: setName(string passedName){
    room name
}

string RoomClass :: getName(){
    return roomName;
}
   
void RoomClass :: setNum(int numCounter){
    roomNum = numCounter;
}
   
int RoomClass :: getNum(){
    return roomNum;
}
       
void RoomClass :: setVisited(bool state){
    visited = state;    
}
   
bool RoomClass :: getVisit(){
    return visited;
}
        
void RoomClass :: setCurrent(bool state){
    current = state;    
}
    
bool RoomClass :: getCurrent(){
    return current;
}
    
int RoomClass :: r1Function(){
        
}


